document.querySelectorAll('.read-more').forEach(button => {
    button.addEventListener('click', () => {
      const content = button.previousElementSibling;
      const readLess = button.nextElementSibling;
      content.style.display = 'block';
      button.style.display = 'none';
      readLess.style.display = 'inline';
    });
  });

  document.querySelectorAll('.read-less').forEach(button => {
    button.addEventListener('click', () => {
      const content = button.previousElementSibling.previousElementSibling;
      const readMore = button.previousElementSibling;
      content.style.display = 'none';
      button.style.display = 'none';
      readMore.style.display = 'inline';
    });
  });